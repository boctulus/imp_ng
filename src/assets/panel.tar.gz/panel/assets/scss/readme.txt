In this theme i user mixin library for Sass (http://bourbon.io/).

I recomment you can try this sass compiler http://alphapixels.com/prepros/ compiler , you can download �prepros sass compiler� is free (not pro)

I glad to help you , please contact me (zicedemo at gmail) ;)

Thank you.